from pathlib import Path

def test_app_files_exist():
    root=Path(__file__).parents[1]
    assert (root/'app/main.py').exists()
    assert (root/'app/static/manifest.webmanifest').exists()
    assert (root/'app/static/sw.js').exists()
