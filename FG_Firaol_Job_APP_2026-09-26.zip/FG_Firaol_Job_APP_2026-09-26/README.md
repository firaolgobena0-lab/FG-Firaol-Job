# FG / Firaol Job — App Build

This is the consolidated runnable FG Job web/PWA application built from the existing project source.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export FG_SESSION_SECRET="replace-with-a-long-random-secret"
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Android
The app is PWA-ready and can be installed from a supported Android browser as an app. A Play Store APK/AAB still requires an Android packaging/signing step and a production server.

## Production requirements
- HTTPS and a real production secret
- PostgreSQL and migrations
- real provider-approved Telebirr/PayPal credentials and verified webhooks
- secure password hashing, MFA, rate limiting and monitoring
- KYC/privacy/legal review
- security and payment testing before real money is enabled

The included payment UI is not a claim that live provider payments are active.
