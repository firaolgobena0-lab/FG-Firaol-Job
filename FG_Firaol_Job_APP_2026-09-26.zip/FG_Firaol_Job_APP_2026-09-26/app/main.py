from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from starlette.middleware.sessions import SessionMiddleware
import sqlite3, hashlib, os, hmac, secrets
from pathlib import Path

BASE=Path(__file__).parent
DB=Path(os.getenv('FG_DB_PATH', str(BASE/'fg_job.db')))
DB.parent.mkdir(parents=True, exist_ok=True)
app=FastAPI(title='FG / Firaol Job')
app.add_middleware(SessionMiddleware, secret_key=os.getenv('FG_SESSION_SECRET','dev-only-change-this-secret'))

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def pw(s):
    salt=secrets.token_bytes(16)
    digest=hashlib.pbkdf2_hmac('sha256', s.encode(), salt, 210000)
    return 'pbkdf2$210000$'+salt.hex()+'$'+digest.hex()

def verify_pw(s, stored):
    try:
        scheme, rounds, salt_hex, digest_hex=stored.split('$',3)
        if scheme!='pbkdf2': return hmac.compare_digest(pw(s), stored)
        digest=hashlib.pbkdf2_hmac('sha256', s.encode(), bytes.fromhex(salt_hex), int(rounds))
        return hmac.compare_digest(digest.hex(), digest_hex)
    except Exception:
        return hmac.compare_digest(pw(s), stored)


def init():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,skills TEXT DEFAULT '',verified INTEGER DEFAULT 0,language TEXT DEFAULT 'om');
    CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY AUTOINCREMENT,business_id INTEGER NOT NULL,title TEXT NOT NULL,description TEXT NOT NULL,skills TEXT DEFAULT '',budget REAL DEFAULT 0,country TEXT DEFAULT 'Ethiopia',status TEXT DEFAULT 'open',created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id INTEGER NOT NULL,worker_id INTEGER NOT NULL,status TEXT DEFAULT 'pending',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,UNIQUE(job_id,worker_id));
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id INTEGER NOT NULL,worker_id INTEGER NOT NULL,gross REAL NOT NULL,fg_fee REAL NOT NULL,worker_net REAL NOT NULL,status TEXT DEFAULT 'pending');
    ''')
    if not c.execute("select id from users where email='admin@firaoljob.com'").fetchone():
        c.execute("insert into users(name,email,password,role,verified) values(?,?,?,?,1)",('Firaol / FG CEO','admin@firaoljob.com',pw('FGadmin123'),'admin'))
    c.commit(); c.close()
init()

T={'om':{'home':'FG / Firaol Job','tag':'Hojii argadhu, jireenya kee jijjiiri.','jobs':'Hojii','register':'Galmaa’i','login':'Seeni','worker':'Hojjetaa','business':'Business','post':'Hojii maxxansi','apply':'Apply','welcome':'Baga nagaan dhuftan','mission':'Rakkoo hojii dargaggootaa furuun carraa hojii addunyaa walitti fiduu.'},
'en':{'home':'FG / Firaol Job','tag':'Find work. Build your future.','jobs':'Jobs','register':'Register','login':'Login','worker':'Worker','business':'Business','post':'Post a job','apply':'Apply','welcome':'Welcome','mission':'Connecting people to opportunities and creating better access to work.'}}
def L(request,k): return T.get(request.query_params.get('lang','om'),T['om']).get(k,k)
def nav(request):
    lang=request.query_params.get('lang','om'); u=request.session.get('user'); userlinks=''
    if u: userlinks=f'<a href="/dashboard?lang={lang}">Dashboard</a><a href="/logout?lang={lang}">Logout</a>'
    else: userlinks=f'<a href="/register?lang={lang}">{L(request,"register")}</a><a href="/login?lang={lang}">{L(request,"login")}</a>'
    return f'''<nav><a class="brand" href="/?lang={lang}"><b>FG</b> <span>/ Firaol Job</span></a><div><a href="/jobs?lang={lang}">{L(request,'jobs')}</a>{userlinks}<a href="/?lang={'en' if lang=='om' else 'om'}">{'EN' if lang=='om' else 'OM'}</a></div></nav>'''
def page(request,body,title='FG / Firaol Job'):
    return HTMLResponse(f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><link rel="manifest" href="/manifest.webmanifest"><meta name="theme-color" content="#0a8f4d"><link rel="icon" href="/static/icon.svg"><style>
:root{{--g:#0a8f4d;--d:#07130d;--bg:#f4faf6;--line:#dce9e1}}*{{box-sizing:border-box}}body{{margin:0;font-family:Inter,system-ui,Arial;background:var(--bg);color:var(--d)}}nav{{position:sticky;top:0;background:#fff;border-bottom:1px solid var(--line);padding:14px 5%;display:flex;justify-content:space-between;align-items:center;z-index:9}}nav a{{text-decoration:none;color:#173524;margin-left:14px;font-weight:700}}.brand{{font-size:22px;color:var(--g)}}.brand span{{color:#111}}main{{max-width:1120px;margin:auto;padding:28px 5%}}.hero{{border-radius:28px;padding:44px;color:#fff;background:linear-gradient(135deg,#042b18,#0a8f4d 65%,#18a965);box-shadow:0 15px 40px #064b2730}}h1{{font-size:clamp(30px,6vw,58px);margin:0 0 12px}}h2{{margin-top:0}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px;margin-top:20px}}.card{{background:#fff;border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 8px 25px #083b1a0b}}.btn{{display:inline-block;border:0;border-radius:12px;padding:12px 17px;background:var(--g);color:#fff;text-decoration:none;font-weight:800;cursor:pointer}}.white{{background:#fff;color:#075b31}}input,textarea,select{{width:100%;padding:12px;margin:7px 0 14px;border:1px solid #cbdad1;border-radius:10px;font-size:15px}}textarea{{min-height:110px}}label{{font-weight:750}}.tag{{display:inline-block;padding:5px 9px;margin:3px;background:#e5f6ed;border-radius:99px;color:#08733e;font-size:13px}}.muted{{color:#64776d}}.alert{{padding:12px;background:#fff5d7;border-radius:10px;margin:12px 0}}.success{{padding:12px;background:#e5f6ed;border-radius:10px;margin:12px 0}}table{{width:100%;border-collapse:collapse;background:#fff}}th,td{{padding:10px;border-bottom:1px solid var(--line);text-align:left}}footer{{padding:35px;text-align:center;color:#64776d}}
</style></head><body>{nav(request)}<main>{body}</main><footer>FG / Firaol Job · {L(request,'mission')}</footer><script>navigator.serviceWorker&&navigator.serviceWorker.register('/sw.js').catch(function(){{}});</script></body></html>''')

def current(request): return request.session.get('user')

@app.get('/manifest.webmanifest')
def manifest():
    return RedirectResponse('/static/manifest.webmanifest')

@app.get('/sw.js')
def service_worker():
    from fastapi.responses import FileResponse
    return FileResponse(BASE/'static/sw.js', media_type='application/javascript')

@app.get('/static/icon.svg')
def icon():
    from fastapi.responses import FileResponse
    return FileResponse(BASE/'static/icon.svg', media_type='image/svg+xml')

@app.get('/',response_class=HTMLResponse)
def home(request:Request):
    return page(request,f'''<section class="hero"><h1>FG / Firaol Job</h1><p>{L(request,'tag')}</p><p>{L(request,'mission')}</p><a class="btn white" href="/register?lang={request.query_params.get('lang','om')}">{L(request,'register')}</a> <a class="btn" href="/jobs?lang={request.query_params.get('lang','om')}">{L(request,'jobs')}</a></section><div class="grid"><div class="card"><h2>👷 {L(request,'worker')}</h2><p>Profile, skills, applications fi hojii argachuu.</p></div><div class="card"><h2>🏢 {L(request,'business')}</h2><p>Hojii bilisaan maxxansi, applicants argadhu.</p></div><div class="card"><h2>🤖 AI Matching</h2><p>Skills fi requirements walitti fiduun matching saffisaa.</p></div><div class="card"><h2>💰 10%</h2><p>Fakkeenya: $100 hojii → $10 FG → $90 worker.</p></div></div>''')

@app.get('/register',response_class=HTMLResponse)
def reg_form(request:Request):
    return page(request,'''<div class="card"><h1>Register</h1><form method="post"><label>Name</label><input name="name" required><label>Email</label><input name="email" type="email" required><label>Password</label><input name="password" type="password" required><label>Account</label><select name="role"><option value="worker">Worker</option><option value="business">Business</option></select><label>Skills</label><input name="skills" placeholder="Python, design, translation..."><button class="btn">Create account</button></form></div>''')
@app.post('/register')
def reg(request:Request,name:str=Form(...),email:str=Form(...),password:str=Form(...),role:str=Form(...),skills:str=Form('')):
    c=db()
    try:c.execute('insert into users(name,email,password,role,skills) values(?,?,?,?,?)',(name,email,pw(password),role,skills));c.commit()
    except sqlite3.IntegrityError:c.close();return page(request,'<div class="alert">Email kun duraan jira.</div>')
    u=c.execute('select * from users where email=?',(email,)).fetchone();c.close();request.session['user']=dict(u);return RedirectResponse('/dashboard',303)

@app.get('/login',response_class=HTMLResponse)
def login_form(request:Request): return page(request,'''<div class="card"><h1>Login</h1><form method="post"><label>Email</label><input name="email" type="email" required><label>Password</label><input name="password" type="password" required><button class="btn">Login</button></form></div>''')
@app.post('/login')
def login(request:Request,email:str=Form(...),password:str=Form(...)):
    c=db();u=c.execute('select * from users where email=?',(email,)).fetchone();c.close()
    if u and not verify_pw(password,u['password']): u=None
    if not u:return page(request,'<div class="alert">Email ykn password sirrii miti.</div>')
    request.session['user']=dict(u);return RedirectResponse('/dashboard',303)
@app.get('/logout')
def logout(request:Request):request.session.clear();return RedirectResponse('/',303)

@app.get('/dashboard',response_class=HTMLResponse)
def dashboard(request:Request):
    u=current(request)
    if not u:return RedirectResponse('/login',303)
    if u['role']=='admin':return RedirectResponse('/admin',303)
    return RedirectResponse(f"/{'worker' if u['role']=='worker' else 'business'}/{u['id']}",303)

@app.get('/jobs',response_class=HTMLResponse)
def jobs(request:Request):
    q=request.query_params.get('q','').strip();c=db()
    if q: rows=c.execute("select jobs.*,users.name business_name from jobs join users on jobs.business_id=users.id where jobs.status='open' and (jobs.title like ? or jobs.skills like ? or jobs.country like ?) order by jobs.id desc",(f'%{q}%',f'%{q}%',f'%{q}%')).fetchall()
    else: rows=c.execute("select jobs.*,users.name business_name from jobs join users on jobs.business_id=users.id where jobs.status='open' order by jobs.id desc").fetchall()
    c.close();cards=''.join(f'''<div class="card"><h2>{j['title']}</h2><p>{j['description']}</p><p>{' '.join('<span class="tag">'+x.strip()+'</span>' for x in j['skills'].split(',') if x.strip())}</p><p><b>${j['budget']:.2f}</b> · {j['country']}</p><a class="btn" href="/jobs/{j['id']}">View / Apply</a></div>''' for j in rows)
    return page(request,f'''<h1>{L(request,'jobs')}</h1><form><input name="q" placeholder="Search jobs, skills, country..." value="{q}"><button class="btn">Search</button></form><div class="grid">{cards or '<div class="card">No jobs found.</div>'}</div>''')

@app.get('/jobs/{jid}',response_class=HTMLResponse)
def job(request:Request,jid:int):
    c=db();j=c.execute('select jobs.*,users.name business_name from jobs join users on jobs.business_id=users.id where jobs.id=?',(jid,)).fetchone();c.close()
    if not j:return page(request,'<div class="alert">Job not found.</div>')
    u=current(request); form=f'''<form method="post" action="/jobs/{jid}/apply"><button class="btn">{L(request,'apply')}</button></form>''' if u and u['role']=='worker' else '<p class="muted">Login as Worker to apply.</p>'
    return page(request,f'''<div class="card"><h1>{j['title']}</h1><p>{j['description']}</p><p><b>Skills:</b> {j['skills']}</p><p><b>Budget:</b> ${j['budget']:.2f}</p><p><b>Country:</b> {j['country']}</p><p class="muted">Business: {j['business_name']}</p>{form}</div>''')
@app.post('/jobs/{jid}/apply')
def apply(request:Request,jid:int):
    u=current(request)
    if not u or u['role']!='worker':return RedirectResponse('/login',303)
    c=db()
    try:c.execute('insert into applications(job_id,worker_id) values(?,?)',(jid,u['id']));c.commit();msg='Application galmaa’e.'
    except sqlite3.IntegrityError:msg='Ati duraan apply gooteetta.'
    c.close();return page(request,f'<div class="success">{msg}</div><a class="btn" href="/jobs">Jobs</a>')

@app.get('/worker/{uid}',response_class=HTMLResponse)
def worker(request:Request,uid:int):
    u=current(request)
    if not u or u['id']!=uid:return RedirectResponse('/login',303)
    c=db();apps=c.execute('select applications.*,jobs.title,jobs.budget from applications join jobs on jobs.id=applications.job_id where worker_id=? order by applications.id desc',(uid,)).fetchall();c.close()
    rows=''.join(f"<li>{a['title']} — ${a['budget']:.2f} — {a['status']}</li>" for a in apps)
    return page(request,f'''<h1>Worker Dashboard</h1><div class="card"><h2>{u['name']}</h2><p>{u['skills'] or 'Skills hin galmeeffamne.'}</p><p>Verified: {'✅' if u['verified'] else '⏳ Pending'}</p></div><div class="card"><h2>Applications</h2><ul>{rows or '<li>No applications yet.</li>'}</ul></div><a class="btn" href="/jobs">Find Jobs</a>''')

@app.get('/business/{uid}',response_class=HTMLResponse)
def business(request:Request,uid:int):
    u=current(request)
    if not u or u['id']!=uid:return RedirectResponse('/login',303)
    c=db();jobs=c.execute('select * from jobs where business_id=? order by id desc',(uid,)).fetchall();apps=c.execute('''select applications.id,applications.status,jobs.title,users.name worker,users.id worker_id from applications join jobs on jobs.id=applications.job_id join users on users.id=applications.worker_id where jobs.business_id=? order by applications.id desc''',(uid,)).fetchall();c.close()
    jl=''.join(f"<li>{j['title']} — ${j['budget']:.2f}</li>" for j in jobs);al=''.join(f"<li>{a['title']} → {a['worker']} — {a['status']}</li>" for a in apps)
    return page(request,f'''<h1>Business Dashboard</h1><div class="card"><h2>{L(request,'post')}</h2><form method="post" action="/business/{uid}/jobs"><label>Title</label><input name="title" required><label>Description</label><textarea name="description" required></textarea><label>Skills</label><input name="skills"><label>Budget USD</label><input name="budget" type="number" step="0.01" required><label>Country</label><input name="country" value="Ethiopia"><button class="btn">Post</button></form></div><div class="grid"><div class="card"><h2>Your Jobs</h2><ul>{jl or '<li>None</li>'}</ul></div><div class="card"><h2>Applicants</h2><ul>{al or '<li>None</li>'}</ul></div></div>''')
@app.post('/business/{uid}/jobs')
def create_job(request:Request,uid:int,title:str=Form(...),description:str=Form(...),skills:str=Form(''),budget:float=Form(...),country:str=Form('Ethiopia')):
    u=current(request)
    if not u or u['id']!=uid or u['role']!='business':return RedirectResponse('/login',303)
    c=db();c.execute('insert into jobs(business_id,title,description,skills,budget,country) values(?,?,?,?,?,?)',(uid,title,description,skills,budget,country));c.commit();c.close();return RedirectResponse(f'/business/{uid}',303)

@app.get('/api/match/{jid}')
def match(jid:int):
    c=db();j=c.execute('select * from jobs where id=?',(jid,)).fetchone();ws=c.execute("select id,name,skills,verified from users where role='worker'").fetchall();c.close()
    if not j:return JSONResponse({'error':'job not found'},404)
    req={x.strip().lower() for x in j['skills'].split(',') if x.strip()};out=[]
    for w in ws:
        sk={x.strip().lower() for x in w['skills'].split(',') if x.strip()};score=round(100*len(req&sk)/len(req),1) if req else 0
        out.append({'worker_id':w['id'],'name':w['name'],'match_score':score,'verified':bool(w['verified'])})
    return sorted(out,key=lambda x:(x['match_score'],x['verified']),reverse=True)

@app.get('/admin',response_class=HTMLResponse)
def admin(request:Request):
    u=current(request)
    if not u or u['role']!='admin':return RedirectResponse('/login',303)
    c=db();users=c.execute('select id,name,email,role,verified from users order by id desc').fetchall();jobs=c.execute('select jobs.id,jobs.title,jobs.budget,jobs.country,users.name business from jobs join users on users.id=jobs.business_id order by jobs.id desc').fetchall();c.close()
    ut=''.join(f"<tr><td>{x['id']}</td><td>{x['name']}</td><td>{x['email']}</td><td>{x['role']}</td><td>{'Yes' if x['verified'] else 'No'}</td></tr>" for x in users);jt=''.join(f"<tr><td>{x['id']}</td><td>{x['title']}</td><td>{x['business']}</td><td>${x['budget']:.2f}</td><td>{x['country']}</td></tr>" for x in jobs)
    return page(request,f'''<h1>FG Admin</h1><div class="card"><h2>Users</h2><table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Verified</th></tr>{ut}</table></div><div class="card"><h2>Jobs</h2><table><tr><th>ID</th><th>Title</th><th>Business</th><th>Budget</th><th>Country</th></tr>{jt}</table></div><div class="alert">Demo admin: admin@firaoljob.com / FGadmin123. Change it before production.</div>''')
